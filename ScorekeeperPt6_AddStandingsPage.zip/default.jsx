import React, { Component } from 'react';
import { AppRegistry, Text, View, StyleSheet, Image, TextInput, ImageBackground, TouchableHighlight, Alert, Dimensions } from 'react-native';
import Constants from 'expo-constants';

let deviceHeight = Dimensions.get('window').height;
let deviceWidth = Dimensions.get('window').width;

export default class App extends Component {
    
    state = {
        //game1
        team1: 0,
        team2: 0,
        name1: 'Team 1 ',
        name2: 'Team 2 ',
        winnerName1: " ",
        
        game1: 'block',
        game2: 'none',
        scoring: 'none',
        
        //game2
        team11: 0,
        team22: 0,
        name11: 'Team 1 ',
        name22: 'Team 2 ',
        winnerName11: " ",
    }
    
    //game1
    updateScore1 = () => {
        this.setState({
            team1: (this.state.team1 + 1)
        })
    }
    
    updateScore2 = () => {
        this.setState({
            team2: (this.state.team2 + 1)
        })
    }
    
    minusScore1 = () => {
        this.setState({
            team1: (this.state.team1 - 1)
        })
    }
    
    minusScore2 = () => {
        this.setState({
            team2: (this.state.team2 - 1)
        })
    }
    
    //
    //game 2
    updateScore11 = () => {
        this.setState({
            team11: (this.state.team11 + 1)
        })
    }
    
    updateScore22 = () => {
        this.setState({
            team22: (this.state.team22 + 1)
        })
    }
    
    minusScore11 = () => {
        this.setState({
            team11: (this.state.team11 - 1)
        })
    }
    
    minusScore22 = () => {
        this.setState({
            team22: (this.state.team22 - 1)
        })
    }
    
    //switch screens
    game1Press = () => this.setState(state => ({
        game1: 'block',
        game2: 'none',
        scoring: 'none',
    }));
    game2Press = () => this.setState(state => ({
        game1: 'none',
        game2: 'block',
        scoring: 'none',
    }));
    scoringPress = () => this.setState(state => ({
        game1: 'none',
        game2: 'none',
        scoring: 'block',
    }));
    
    chooseWinner1 = () => {
        if (this.state.team1 < this.state.team2) {
            this.setState({ 
                winnerName1: this.state.team2
            })
        } else if (this.state.team1 > this.state.team2) {
            this.setState({ 
                winnerName1: this.state.team1
            })
        } else if (this.state.team1 == this.state.team2) {
            this.setState({ 
                winnerName1: "There is a tie. Nobody "
            })
        }
    }
    
    chooseWinner11 = () => {
        if (this.state.team11 < this.state.team22) {
            this.setState({ 
                winnerName11: this.state.team22
            })
        } else if (this.state.team11 > this.state.team22) {
            this.setState({ 
                winnerName11: this.state.team11
            })
        } else if (this.state.team1 == this.state.team2) {
            this.setState({ 
                winnerName11: "There is a tie. Nobody "
            })
        }
    }
    
    render() {
        return (
            <View style={styles.container}>
            {/*CONTENT CONTAINER for game 1*/}
                <View style={{ display: this.state.game1 }}>
                    <View style={styles.contentContainer}>
                        <ImageBackground
                            style={styles.background}
                            source={{ uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxATEBASEBAVFRUVFQ8PEBUVFxcVFRUXFRUWFhUVFRUYHSggGBolHRUVITEhJSorLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGy0lHyUtLS0tLS0tLS0tLS0tLS0tLS0tLS8tLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIANUA7QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQIDBAUGB//EAEAQAAIBAgEHCgMGBQMFAAAAAAABAgMRBAUSITFhcaEGEzJBUYGRscHRFSLwFDNCUmJyQ4KSsuEWU6IkJbPC8f/EABoBAQEBAQEBAQAAAAAAAAAAAAABAgMEBQb/xAA6EQACAQICBggFAQcFAAAAAAAAAQIDEQQhBRIxUXGREzJBYYGhscEUIkLR4fAVM1JTgqLxIyRicpL/2gAMAwEAAhEDEQA/APqQBNOKbSbsu09h+WSu7EFUzpRw8FqV9r0/4MkacexeCOfSI9ywE7ZtHMhBvUrmVYWf5eKOhTppalbrMhHUfYdI4GNvmbv3f4OWsJPs4ot9in9M6QJ0jN/BUu/mcqWFmurw0mE7Zy8bJOejc95qM75M8+Iw0acdaL8DASVB0PFYsDep4ODV85vdYyfYYbfEx0kT1xwNVq+XM5gO1CmlqSRe5npe49C0a7Zy8vz7HCMsMNN6o+h0/s8L3zVcykdXcWno7P53y/JxqlGUdaZjO6aVfCRemOj64FVXeZq6Pazpu/cznRdywlFptMHU+a007MAAEAEUZFBEbsajFy2GMGWwM65vou8xAvKJQ0ncxKLTsQRclkJFCJi2tT8GZY4ma/F5GMEsiqpJdV2NhY2ZdY/thxNMkmpE6rE1V9Xo/VG79vX5SJY/sjxNME1IleLrb/JGWriZPrsjASDaVthxc5Sd5O5eE7LUQ423+RCIJYXyJhJrSnY2qWPkukr8GaoDintNU606fUdv1u2HQ+IR7HwIhjlfSrLx8TQBno4nf46tvXI7CrwfWHXh2o4xEjPQredv2jP+FHRq46PVd8DA8bLqVuJqpElVOJxqY2rLttw/V/Mmcm3d6wAdDyXvtAABALgADOZm526skYAmZcUdI1Gu0tNkAGjLd2AADIAABAABSQQSCAAAAAAAAgAkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgkAEAAFJBBIIAAAUqVEjHz/wClkV180e7+4zmM23bI9jjSp04uUdZvPa129xi5/wDTIjn/ANMjMC2lv8jHS0f5f9zMPP8A6ZDn/wBLMwFpb/IdLR/l/wBzMdKqmZTWirT+uw2BFtrMmIhCElqbGk+ZIANHnAAAAAAAAAAAAABAKSCpIFiQQUlWitckSUlFXk7cQk3sMhBrTx0epN8DBLHS6klxPFU0lhofVfgm/PZ5neOGqvs55HQBy5Ymb/E+7QYpSb1s8k9MwXVg3xaXpc7LAy7WvU60qkVrkvEo8VD83mcolw0cTg9MVX1Yrxu/sdVgY9rZvVMTFyTV9FvMu8dHsfD3OaDh+1cR3cvydZYeEkk+zYdD7dH8r4D7evys54J+1MTvXJGfhKW7zOj9vj2PgSsbDsfD3OaCrSuJXauRHg6XfzN6OJjnXvo3bDZWIg/xLy8zkpE2OkNLV1tinzXuWphoztm8klyOxGSepp7ixwzJGrJapPxPRDTK+qHJ38re5weBfZLyOwDmRxs1rs/rYZ4Y9datu0nrp6Uw09rtxXvmvM4ywlVdl+BtgxQxEHqfjoMp7oTjNXi7ruzODTjk0SCAaISCttNywDVgQalXHJdFX29Rq1K8pa36I+dW0pQhlH5n3bOf2uemnhZyzeR069SEevTqstNzVq4xrVG2/T5GnCWatupbEY3NHy62lK0l8vy8NvP/AAe1YWmtqv6GadeT1yfkYirqFc9nzJzcneTvxzO6jbYZBcxNkGbmrGbPRXPRjLRV9X+e4K7Fi6n124idQxuRBXO2SKWz2M9lRcxrd5C+eyM5lbi5NZbwWz2M9lbi5dZbxkbFN3lZ6tPeTUjptFbd3ea+veXc7Ky/me06KUbO5Q5/5GejGDDlcljLnIkwgtyWMxlp1pLU36eBq5zLc4ajNxetF2fcHFNWZ0KeP/Mu9GzTrRep/W45Cl1/XeXufTpaUrU1afzccnzXun33PNLCQeay9OR2STl0sXJdd1t9zcp4yDWln16OkaFXt1X35eZ4amGqR7L8DkuZVzZ14ZAna9SpCC8fZEPDYOHSqym+xauC9T838JVWc7RX/JpH2tRo45MIt6k3u0nW+IYaP3eHT2yfvcrPL1XVFQgti9ydFSXWqck35uwst5rU8m1paqUu9ZvmZ4ZDr9aUf3SXpc16mU68tdV9zzfKxq1JN623v0kvh1sUnxaXom/MZHU+EwXTxMFu+b1RH2XCrXiJP9sX7M5OcTcz01NdWmvFyfui+B1f+iXVUl4L2KvEYVasPJ/zteTOU2QPiX2Riv6V73FzqvKNFasLHvk36E/F49WHpeFzkgLF1VsdvCK9ELs7uByvFySq06cYvRdRtZ7degyZTxVajLoQcH0JKCtuenWeeOlgMqOEebqRz6b0Zr6tz9PI708bKUdScmn2SXo0tq4ZrvNJ7y/xyr2Q/pQ+O1eyH9KLSyfQqaaFZRf5J6Gtif8A93lfgNf9G/O0Gv8Ae/S3Jb4u68vew+YfHKv5Yf0o2MFj61WWbGlTf5m46IrtekwfD6NP7+sn+iGlve+oxYvKbcebpR5un2LXLe/rvHTVqedab/6ppt+0eLz3Zjizex+VqUZZtOlTnbRKTirX2bDX+LU+vDU+7R6HIBwlja0m3dcLL3TI2zrrH4d68Ku6T9ieewb10JLdJvzZxyUzKxUu1Rf9MfsiXZ2LYJ9dSPH0ZKwWEfRxDX7o+6Rx7sZxr4mPbTjya9GPA7KyJF9DE05dy9GyJ8n6y1Zr3P3RyLovTqyXRk1ubXkVVKD207cJP3TJdbjbqZJxC10n3WfkzWqUJx6UJR3przNiGVK8dVWXf83mbVPlBWWtKW9W8mW2GfbJcUn6NMvys5amWU0df41Tl97QT2qz816k5+AlpcZR2fP/AOraL8PF9WrHxvH2JqLecWpUlJ3lJt9rd/Mgo5FTxuWdxYvnFc4gEuLEhEEohRYMXABAAAAAAAAAJBFxclkwALi5QAAAAAASSCC7AQSCCAtnEqRQFuSxkBQnOLclioAMmgAS0+sWADDkUciXBYXKXIFy2LuRGcVBLlsTnMi5JAAABAAAAWKgFAJuQWSAGcTnFUQAXziTGBcljKCikTnFuQkAFAAAAFyrkE/8Mly2MsLa/pd3X6XMU53E5aXbrKllLKyKAAYAAAALJFS0SraDLClJq60Lq06zHr0PX1ezL0Kkl8qt39QqyS0R731vvOmWrcphAByIAAAAAASZUkl6/Wrd13KQfrf69CGzeSVykNkAGCAAAAAAF49pmcJJXfB6jCtXEy06jkrSaSWt9bOsNxSv0ypNSpd6FZdnuVUjLaM2Khydkn1fViAZvYoABAAWKlAAIuQEghzRGeLopfO9iCuebOEwNar93TbXbqXi9BqKc3ZXb7sxYwA7tDkxVfTqRjsScvYz/BcLD7yvp7HKMeFrnsjo7EPNq3FpfkuqzzYPRunkyOt376j/ALSedyZs8KvsT4K22rTX9X4GqebJTPR/9sfX/wCVeZb4bgZ9GrZ7JK/hI0sBOXUnB8Jfgap5uUrlT0VXkvfTTrX7M5eq9jm4rImJhp5vOXbDTw18DnVwWIhnKD8M/QWZzwVcuponPPHdEJBGchcpCQSkQ2ASGyAW4AAIADG5EEuWxlzkVzygJcti2exnFQS5bE2DMlGjOeiEJS3JvyN6jkHEy/h22yaXC9zrCjUn1It8Ff8ABTmGXC4edSahBXb1e77EdqnyVqvpVILdp9EdvI2SI0FL5s6UrXla2jsWk9tDRlac0pqy7Xl+vIWNClkvDYaCqYhqUtulX7FHr3vgamN5UTeijFQXU5aZeGpcTt4zItKrPPqOTepLOskuxJFY8nsKv4d98pe59OeFxKWph9WEfG74uz+/eDxuIxtWfTqSlsd7eGowI958Mwq106ffb1LfZsIvwUvCJ45aIqSd5zV/Fix4EHv+awv5aPhAtzOGf4aXhEfseX8a5fkHz4H0FYLDvVSpvdGPsQ8k4d/wYdyt5B6Fm9k1yFjwVGtOGmEpR3NryOtg+UdeHTtUW3R4SXrc9FLIWFf8JdzkvJmKfJvDPVFrdJ+tyw0di6P7uaXBu3K1hYw06uFxatKNp21PRNbU+tfVjg5XyROg79KD0Rl6NdTO9/pmmmpQqVItO6d07PwOrVw6nTcJ6brNk7W09qXVp0npng54iD6ZJT7JLt4r18rbAfOiUjs1OTGIWpwlubT4o1auR8THXRl3Wl/a2fEnhK8etB8r+lwaFxnMmpBx0STT3P1KnBvOxDIphSRjAuSxlBiTLZ5bksVB2cHycrz0ztTX6tL8F62OzQyBh6Szqjzra3N2j4avG57KOjq9TO1lveXlt8jdjyFGjObtCLk+xJvyOrhuTeIl0koLa7vwR2q3KDDU1m01nW1KCtHxdl4XOViOU9aXQioL+p8dHA79Bg6T/wBSes90dn68QdDDclaS+8nKW75V6vibXNYKjr5tNdrzpcbs8licfWn06knsvZeC0GoFj6NL9zSXF7fd/wBwPaVeUuHjoi5S/bGy/wCVjSq8q3+Cj3yl6Jep5kHOelMTLtS4L73Fzs1eU2IerNjujfzbN7IGXJSk4V53cn8kmklf8ujgeYBzp4+vGak5N27G8gem5Q4GupSqU51JQemUU28ztsr6t2o81KTett73c7OTOUVSmlGos+K0LT8y7+vv8Tpz+w4jS2lN/wAkr+UuJ6KlGli3rUp2k/pl7P7X8AeRsTY9JiOSstdOqn2KatxXsaNXk9il+BS3SXq0eSejq9PbT5K/pcHIBvSyViFroz7lfyMfw6t/s1P6X7HH4ea+h/8Al/YGq4ItGTWptbnY24ZNrvVRn4NGankHEv8AhNd8V6ljhqn0wfhFg1YY6stVWa3SfuZ4ZaxK1Vn32fmjoUeStV9OcY7ryfob8Mk4OhprSUn+t+UFr4nvp4PGbW3Fb3K3o7+gMORsoYurJdFwvpm42W5Wauzr5UynChFOWlvoxWt9vccjG8popZtCOxSasluj72PN4ivKcnKcnJvrZ3nj1Qp6kJuct72Lhv7tvFi562jymoPpKUd9muD9DfoZVoT6NWO5vNfg7Hz8HGGl6y6yT8vf2Fz6W0pLTZrxRpV8j4eWulFbY/K/+Njw1CvOHQnKO5teR0cPyixEdclL9y9VZnqWlaNRWqw8lJedvQp18RyVpPoTlHfaS9HxOZiOTNePRtNbHZ+D0cToYflVH+JSa2xd+DsdTC5XoVOjUV+x/K/B6zSoYCv1LJ9zs+T+xMjw+IwlSn95CUd60eOown0vQ7q2jgzSrZGw0neVJX2XjwTRxq6Ga6k+a919hY42VeUFVTnTppRzXZy6Te5PQuJ56tXnUlFzk5N6m29G4A8GIrTqylru9m1bs5bAW5pFXT2kA5SiiE83tHN7QDCigOb2jmtoBdVAvzG3gOY28ADXRxA5jbwL/Z7LX1J6u12IBuNONnkDLh61WHQqyjsTdvC9jeo5cxK11FL90V6WIBt1J0oXhJrxfpexTOuU1XrhB+K9S/8Aqif+1HxYAhpHEtdf0+wEuUtTqpx77v1MNblBiOpxW6Pu2Ab+OxErpzfoDRq5SxE286tK3Yvl/tsaihe7u72vfXqAOU7yfzNvbtbfqCvN7SOb2kA89kQnm9pDiQCWQFhYAgFi0IJ/Xa7AGoJN2YNmhj60LOnUcdmuOvsZ06XKuoladOMn2puPDSSD0SxVain0cmtnpuZT/9k=' }}
                        >
                        
                            <View style={styles.textContainer}>
                                <Text style={styles.title}>
                                    {this.state.name1} vs. {this.state.name2}
                                </Text>
                                <View style={styles.buttonContainer}>
                                    <View style={styles.button}>
                                        <TouchableHighlight
                                            style={styles.button}
                                            onPress = {this.updateScore1}
                                        >
                                            <Text style={styles.buttonText}>
                                                {this.state.name1} Scored!!!
                                            </Text>
                                        </TouchableHighlight>
                                    </View>
                                    <View style={styles.button}>
                                        <TouchableHighlight
                                            style={styles.button}
                                            onPress = {this.minusScore1}
                                        >
                                            <Text style={styles.buttonText}>
                                                {this.state.name1} Lost Points
                                            </Text>
                                        </TouchableHighlight>
                                    </View>
                                </View>
                                
                                <View style={styles.buttonContainer}>
                                    <View style={styles.button}>
                                        <TouchableHighlight
                                            style={styles.button}
                                            onPress = {this.updateScore2}
                                        >
                                            <Text style={styles.buttonText}>
                                                {this.state.name2} Scored!!!
                                            </Text>
                                        </TouchableHighlight>
                                    </View>
                                    <View style={styles.button}>
                                        <TouchableHighlight
                                            style={styles.button}
                                            onPress = {this.minusScore2}
                                        >
                                            <Text style={styles.buttonText}>
                                                {this.state.name2} Lost Points
                                            </Text>
                                        </TouchableHighlight>
                                    </View>
                                </View>
                                
                                <View style={styles.scoreContainer}>
                                    <Text style={{color: 'purple',fontSize: 40,fontWeight: "bold",margin: 10}}>
                                        SCORE
                                    </Text>
                                    
                                    <TextInput style={styles.paragraph}
                                        onChangeText={(name1) => this.setState({name1})}
                                        value={this.state.name1}
                                    />
                                    <TextInput style={styles.paragraph}
                                        onChangeText={(team1) => this.setState({team1})}
                                        value={this.state.team1}
                                    />
                                    
                                    <TextInput style={styles.paragraph}
                                        onChangeText={(name2) => this.setState({name2})}
                                        value={this.state.name2}
                                    />
                                    <TextInput style={styles.paragraph}
                                        onChangeText={(team2) => this.setState({team2})}
                                        value={this.state.team2}
                                    />
                                </View>
                                <TouchableHighlight
                                    style={styles.button}
                                    onPress = {this.chooseWinner1}
                                >
                                    <View style={styles.buttonView}>
                                        <Text style={styles.buttonText}>
                                            Submit Score
                                        </Text>
                                    </View>
                                </TouchableHighlight>
                            </View>
                        </ImageBackground>
                    </View>
                </View>
                
                {/*CONTENT CONTAINER for game 2*/}
                <View style={{ display: this.state.game2 }}>
                    <View style={styles.contentContainer}>
                        <ImageBackground
                            style={styles.background}
                            source={{ uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYSFRgWFBISGRUaGBgcGBoZEhgZGBkYGRgaGhkYGBocIS4lHh4rIRgYJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHhISHjErIys2NDY0NDQ0NDQ0MTQ0PTY0MToxMTU0NDQ0NDQ0NDQxNDQ0NDQ0NDQ0NDE0NDQ0NDQ0NP/AABEIAKgBLAMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAAAwIEBQEGB//EAEIQAAEDAgMEBQsDAQUJAAAAAAEAAhEDEgQhMQVBUZEVImFxgQYTIzJCYpKhscHRFFLhcjRDY7LxM1NUc4KTotLw/8QAGgEBAQEBAQEBAAAAAAAAAAAAAAECAwQFBv/EACcRAAICAgEDBAIDAQAAAAAAAAABAhEDElEhMUEEE2GRInEUUqEy/9oADAMBAAIRAxEAPwD6JCnTpFxgD+F1tMkwNVoMYGCB4ntXRs8MYbd+wpmGa3dce3TkmGp28lFxXIUO3boid/b810mdQCO1LhdCCyticMG9Zvq/RV7VqD5HVSEDQAJZiWJN2jJLUQtYgOycAVRrUbTHJVMxLHr1K9qIT2UCRIHzCi5kZFWzOoqEQmQiEJQuEQmQiEFC4RCZCIQULhEJkIhBQuEQmQiEGouEQmQiEFC4RCbai1BQqF2Ey1FqChcLkJtqLULQqF2Ey1WGYWdVLKot9inCIV12E4KuWpYlFruKhEJzWSYATv0Z4hLCg32I0WwEyF1rIEFRUOqVFOptrDsM3y7gwFw5jL5rlPygoOMXuH9TCBzXiUL479fkvsjO7PozHBwBBBBzBBkHuK7C895K1i1rw49S4W6653R/4r0DKrTo4L6mGe8FKqs2pJnYRClCIXQtA1SXGhTEDMqGkiKHtDhDuaiaw3Dmo+ePBvJUloGU4gSIBnt0S8TqO5N/Ue6OaSc1EZlVUhUItWTivKBjSQxhfG+bW+GRJVVvlI7fSbHY8j7Lg/V4Yumzn0PQwiEjZ2PZXaS2QWxc06idD2jI5q3C7xlGS2i7RaFQuwmQiFRqLhEJkIhBqLtRamQiEGou1FqZCIQai7V1rJKnC6BCBI44gaNCjI/b80wtXLUK0xdg/wBVwtTIXYQlBh2Z9ytPfAySKRgptfcVGdY9Ii7nDOUPYJmNVMEIOaoo7RYBmAuued0ZIY6F1zDMtOqhrx0IVj9EmCnebnUptPRLI1Z8824xlRt9J8PJ6zAIniez6FefwhJM3RETmZPZ8laxGIYerdnPb9VWYwNcY4D6uXxXJyttVfCPOuzs9FS208NDWhmQAmDu7JhW9l7Qe99ryCCDGQEEdy83SNoLjn3RoTrnuWts3BGpmHAFpbPid3Jax5cvuRSbfwZrpZ7CjiiMjmPmr6x1bwlf2T4fhfaaOmOfhl9rUmoZPYm3EqBasnZ9hcJrKXFda2NVK5LIoryFnBLc2dyaHLwm3WvbXcXE+tLDOVvshvCAuGbK8UbqxJpIjtzZhwzp/uzJa7h7p7R81j/q2cfkVqu2q8sc1xDwWx18yB46+K840C/1TaZgO4x/C+VKOObuN/rg4dG3R7PyepObNQOgOEDflOZPJbtDGseYubO+0g8wNF8+p1iTB0V/Z2I829rokaGDuOX4PgvTh9SsdQrp5dkTaPe2FctSMPigBDvA/ZMq4psZZlfUpnVSjVk7UWqia7v3FWcNWuyOv1VoypRbobapNZKlauqHSiNgXLApWotQtEbEEKZYuWoSiFqLVO1dtUsULtRamWotSxRXrVG0xc9wa3iU5rso1CwfKqpAY3cS5x8IA+pWvs7OlTJ/Y3/KEvrRzjO5uPA4GO5SDwu2rjnNbm6IkBU69jjnDcpMZxyCX+ubnDe7LXs7Fw4xpEie4/bcpTG0eR7jyWbV27SYbb25a571ca9rxk77ELw2I2ZUY4tDbgNHA5EcV5885wS1VmZSfg826i0HPIHQzl3FdxFQMMEwHNIB7R/qvVs2bRdTJa4kkxJbpxFukQV4rauFFCu5hhzWuaYGha5ofAnvheSWGcUm10GBRyvv4+zW2bg/PWgk9do1JgyJzjcvW7L2eaRJc4EkAQJgZ9uq5svAMYGvY64FoLDAADSMoA7For1em9Nr+c118dexwm3YIQhe0yX8NigRDjB+RTHYloPrcs1mLhMaqao6LLJKjabnmFGo8NEuMD5nuWFhtuspuLalzW5WOIJDgdHCM4Md2ip0dvNqAXnr6ANa4yNR45/RTV2ej8tbS6noK2LHsjPt00H88lg7WxzWdQsDy4SQdANx75V9rpErK2pg/OPBDoMAGRlE5Fcs6n7bWNWzyyk2/wAjyeMxD2mBkOIzn5ZKiHEuGpMn6FbOIwrg4yOYVJ1NrXNm1uZ3gey5fJX4qmqZYO30+QoOdmLXSRkQQCPGe5em8nadznNLA42tOl0EHdz+Sp4DZb3wQIac7joR7o3p+2mim1lNgd+4uBzJzGcLeGEtvca6LnybitnqemNF37HfCVCF5elc0RdUPiVO4/4nMr6P8j4Oj9P8npYUmEgyF5iXf4nMol3+JzKfyPj/AEn8f5PeUusAR/opuEZnILwF7uNTmVUdUdTe1/pHQQ6CTBz0WHmrwdteh9Ic4AXTl3pGHxgA6xGbo7hGvNZ08kAr1UeZ5Xdo0ekAYkZe12doTqTw4SFkK1gKsOtOh+u5HHgQytyqRoWotU7V21ZPTqLtRamWpGJrBg7Tp+UI6StnnPKwi5kHc+ezNqlsnaDnS2eqxrQ3IbhGfJYVeQ5wJ9p3OcytbYrIYTxd8hl9ZUXWR8lZJSytrob7caI6zTPZoqlaqXnPwHBQQulHpc5NUwQhCpAWJidrvD3BgbaCRnMmMp1WxUqNYJc4AcSYCya+HoOcXCuBJkgOETvXn9QptLR0VIp4LaTCA11SnAEjrtEcV5TyirNdiHlrmkQzMOBB6g0K1cI8NMm9ovcf9m8mJJByHaOSxsdh31Kj3inUgvJEsMxunthYy5ISgo7eeTfom4Nt/wCnqfI7bDPNGnUqMaaZ6pc8AFju0ncZHiF6L9fS/wB7Tnh5xpOXZK+d7JFSjVY+ypEw6GOm05HdqNR2gL0+F2gxodLqgl7zaKLz1HOMWmMiGkAd26VrFmhrTl2NZore154NLD7QYXENrUoe4kFz2wMgMjMZALQfi6IybXpmDDvSNm4a7+1YGO2pTfSqsBrFzmOa0mi8EyMjJmM8h3NlTq7VpEMgVZBl3oX5y3rNPUg9bQmd2kZ796H9kdJqCjSSNj9dS087S/7jPyqFTD4d1QvfiGPJZcOuwNutyZqTu4rOxm0abrA0VoDwTNF+Tc5GYzzIJ3G0cSVc6YowCRVvA/4d3W6rWlriTvs14O0ySWfGl0kc8Lps0qP6euCKr6QDXdX0gabRrBnQpGOw+GpOa6m6nIa4/wC2L847XFUK22Kd9NzRVIZfcTQdJJaA0kZzmJzJMuJ3QYY3a1Ko6Q2vbbEGkcnSZc0BogHKYjMc+Uc0Ev8Ao9ayqzVweOplg9JTmASPONynxVXauPY0BwqU7YILrxaPHjnosSpjGmqxwbWsDHhxFNwJLiy0Z7oBGeoy4KxSxDLGgXNgdaKbwT1cyAM8znHfB0Xojmx/2R4cqcpNlU7Ua8i5wjMMc4gSBn3gcCe1YO2CDUJBBlrSYIMGIiR3LYqiQ4NvIh0TTcJ1jXSZy4LO2pQNrDa6QLTkdYBnnJ8V4vUTxyjSav8AZn0KccttPraPReS+0m1KTKD67abmyAS4BxAMtDZyiCB4c6zgX1STeTdrqTbpn4Becw1zWv8AROc625noyTe0y0DLeoYbaeKBM4WoMj/dPPbG7NZ9xSgla6fJ9JY0pNprqeyDex3JdI7Hrx9LbONJg4RwHHzbsuZXBtfHT/ZTb/yzP1UuPK+y6/K+z2Edj0R2P/8AvBeQq7XxodAwziOPmzn3LlbbGNEWYZ54zSdyS48r7Lr8r7PYQeDlXxjCWzDsjwXl37YxloIwz7jqPNOy8Vx+2MYWf2V9xyjzT8u2UdNd19jX5R7jZjm+ZufiHstdaG3MBI6pkAxlLvktCpSYxs/rSQNwewk92eeoXgNhbRrioDVwzw21wd1HiQRIgntDQQdxPHL07NsPF5cari9pa4Fjw0Tvb2jOO9dV6mMEoy6/o8uWKjLwauI2hRwwl+JvuiBc1zspmAD9eCngdsMqC5vVHs3vY1zjlFrZ7RmY1C81tCsyrWY806jmCZmmQ4C2GtbIgNEaac1qVtsXZjzoeWlrh5uG74jM5CXRPFdn6nHSpmFGLbbN5vldQBDX3NdMZ2gTxMuy0J8E6t5SUolj6ZnQ3tM8ivHY/Fse/Dusqv8ANvl5dTPqhhAa0DdMePZKltDaLHt9GKt59Zz6L5tAIEHM3Z6iIgRoAnv4mrTNbSur6Gu7ytLHO61F3/XprkQDkku8qQ9wL/N58Kg090HVY+IxrXikPNvhrpeDSfEAZAdXf495gBLqVWEmG1Q2BHonSXTvju14krSz467qzGS3F0y7j9oUXvubUZn6wLhIcB+BPgVVxO2Hsp+hraEmA1jurnd7JyE6qpVcSWGHm1wJ9G+IDD2b9FoYLFMaH3efBIAypvlzQQS2Y1MDORv45c/cx3ex4sMJRyKTX74Kmz/K57TFUse074DS3t6ozC2B5TN4U+Pr7uOiyCaRqNd5t1oa8H0DtXWxEtzIAyJ4HjKkxzA6LKgZMj0dTWZMgCIzIju7V1jmxru19n0MijJ3FJG9g9tioQPRtbMXGp8miMzkckbU2o6lDqbqT2Exb1g8HTIgw7wEhZjMc1jnWmpYWMbPmXz1Q64RbvloPG0EzmrFHarevcaoLtIpVIDYMMIDI1gk8MpMQo88LtNVxZIxjXWh+y/KChiDZVDWyRALrmuO4AwOtO5OxWNwzHFradEgRnnwC8yHMFgFN0NYwOIouukNAMZa5T3mc1sYnazSRAqOhrQT5l+oEECWzHfmk8+Lkipdi30azi/mPwjo5nF/MfhWpRK/I7S5N0ir0czi/mPwjo5nF/MfhWpRKbS5FIrdHM4v5j8I6OZ73MfhWZRKbS5FIrdHM97mu9HM97mrEolNnyKRX6PZ73xI6PZ73xKxKJTaXIpFfo9nB3xI6PZwd8SsSiU2lyKRXOz2cHfEudHM97n/AArMolNnyWkV+jme9zR0cz3uasSiU2fIpFfo9nB3xI/QM4H4irIngV0sPB3IpcuRRWZs9h3HQ+0dwJXP0DOB+Iq7SpkH1XeqRof2lLtPA8kuQor9Hs4H4ijo9nA/EVYz7eS5KbS5FIR0ezgfiKOj2cD8RT5RKbS5JSK/R7OB+Io6PZwPxFWJRKbS5FIr9Hs4O+JHR7ODviT7l2U2lyWkV+j2e98SOjme9zViUSm0uRSK3RzPe5o6OZ73NWZRKbS5JSK3RzPe5j8LvRrPf5j8KxKJTaXIpFXo5nF/MfhHRzOL+Y/CtSiU2lyKRV6OZxfzH4R0azi/mPwrUolNpcikQuRclyiVKAy5FyXKJSgMuRclyiUoDLlwOUJRKUBlyLlGmwuMDVXW4dlMXPMxrOnJVRsqKzGl2gJTDhyM3Oa0dpVbEbTccmdVvz/hUnPJzJJParqRyRpuqUx7Tnf0tj6qBxTBpT5uJ+QWfci5WibMvHGHc1g7mD7yonGP/eR3AD6Knci5KZNmWjinn23/ABFc8879zviKrXIuSiWW6NQ3anR28/tK4MQ797viKXhndcdzv8pSbkoeC0MS/wDe/wCIqX6t/wC93OfqqdyLkpi2XRjH7y097G/hSGM4sYfAj6FULkXJRdmaIxLDqxw7nT9VNpY7SpHY4R89Fl3IuSi7M1jh3aiHDiDKU7LUEd6oMrFubSR3FX6G0pyqAEcY+o/CmpVJM5ci5W6uEBzYfnke5UXAgwdVHGisnci5LlEqUQZci5LlEpQGXIuS5RKUBlyLkuUSlAXci5LlFy1QGXIuS7kXJQGXIuS7kXJQGXIuS7kXJQNHZzx1hvy5Ju0aZewhuuRjjG5ZbXkGQc1dpY8e0PEfhaRb6UY1yLls1sLTq5gi7i05+IWfW2U8eqQ4d8Hkcvmr0MOLK1yLlCpSez1muHeDHNLuWqIPuRckXIuSgPuRckXIuSgXcE7rt8foUgOU9nu9IzvP0KrBylDwPuRck3IuSgOuRck3IuSgOuRckXJlNjn+q1x7gUoE7kBytUdlvd6xDR3yeQ/K0KOGZSznPi45+AU6FUWWcI0tY0O1Az/Cq7QcLhxjP7LlbH7mDxP2CpOfOZUZtsnci5LuRcs0QZci5LuRclAZci5LuRclAZci5LuRclAhKJS7kXLVAZKJS7kXJQGSiUu5FyUBkolLuRclAZKJS7kXJQGByazFvb7R8c1WuRcrQL7dou3gHukLjq9N3rUx8I+qo3IuUJZbNDDncR4u/lQOz6R0qOHeR+FXuRcrbA47LYdKw5A/dcOyOFRp8P5SrkXK2wWsJs19N7XFzIB3TOnckdDP/ez5/hSwjuu3v+yW85nvUtgn0O7e9vIqQ2SN9UfCP/ZJlFyuzBYGzqY1qk9xb/KmMNQbvJ8XfaFUuRcpbBebVpN9WmPhH1Oak7aJ3NA7zKz7kXKCy0/GPd7R8MkkuS7kXK0UZKJS7kXJQGSiUu5FyUBkolLuRclAZKJS7kXJQGSiUu5FyUBUolQlEqksnKJUJRKCycolQlEoLJyiUuV2UoWTlEqEolBZOUSoSiUFk5RKhKJQWTlEqEolBYy5clQlEoLLWEPXb3/ZLqHrHvP1Rgz129/2UKx6zv6j9UFhKJUJRKCycolQlEoLJyiVCUSgsnKJUJRKCycolQlEoLJyiVCUSgsnKJUJRKCycolQlEoLJyiVCUSgs4hCEICEIQAhCEAIQhACEIQAhCEAIQhACEIQAhCEA7B+u3v+xUcR67v6j9UITyBaEIQAhCEAIQhACEIQAhCEAIQhACEIQAghCEAIQhAf/9k=' }}
                        >
                        
                            <View style={styles.textContainer}>
                                <Text style={styles.title}>
                                    {this.state.name11} vs. {this.state.name22}
                                </Text>
                                <View style={styles.buttonContainer}>
                                    <View style={styles.button}>
                                        <TouchableHighlight
                                            style={styles.button}
                                            onPress = {this.updateScore11}
                                        >
                                            <Text style={styles.buttonText}>
                                                {this.state.name11} Scored!!!
                                            </Text>
                                        </TouchableHighlight>
                                    </View>
                                    <View style={styles.button}>
                                        <TouchableHighlight
                                            style={styles.button}
                                            onPress = {this.minusScore11}
                                        >
                                            <Text style={styles.buttonText}>
                                                {this.state.name11} Lost Points
                                            </Text>
                                        </TouchableHighlight>
                                    </View>
                                </View>
                                
                                <View style={styles.buttonContainer}>
                                    <View style={styles.button}>
                                        <TouchableHighlight
                                            style={styles.button}
                                            onPress = {this.updateScore22}
                                        >
                                            <Text style={styles.buttonText}>
                                                {this.state.name22} Scored!!!
                                            </Text>
                                        </TouchableHighlight>
                                    </View>
                                    <View style={styles.button}>
                                        <TouchableHighlight
                                            style={styles.button}
                                            onPress = {this.minusScore22}
                                        >
                                            <Text style={styles.buttonText}>
                                                {this.state.name22} Lost Points
                                            </Text>
                                        </TouchableHighlight>
                                    </View>
                                </View>
                                
                                <View style={styles.scoreContainer}>
                                    <Text style={{color: 'purple',fontSize: 40,fontWeight: "bold",margin: 10}}>
                                        SCORE
                                    </Text>
                                    
                                    <TextInput style={styles.paragraph}
                                        onChangeText={(name11) => this.setState({name11})}
                                        value={this.state.name11}
                                    />
                                    <TextInput style={styles.paragraph}
                                        onChangeText={(team11) => this.setState({team11})}
                                        value={this.state.team11}
                                    />
                                    
                                    <TextInput style={styles.paragraph}
                                        onChangeText={(name22) => this.setState({name22})}
                                        value={this.state.name22}
                                    />
                                    <TextInput style={styles.paragraph}
                                        onChangeText={(team22) => this.setState({team22})}
                                        value={this.state.team22}
                                    />
                                </View>
                            </View>
                        </ImageBackground>
                    </View>
                </View>
                
                <View style={{ display: this.state.scoring }}>
                    <View style={styles.contentContainer}>
                        <Text style={styles.paragraph}>
                            is Winning Game 1
                        </Text>
                    </View>
                </View>
                
                
                
                {/*NAVBAR CONTAINER*/}
                <View style={styles.navbarContainer}>
                    <TouchableHighlight style={styles.button}
                        onPress={this.game1Press}
                    >
                        <Text>
                            Game 1
                        </Text>
                    </TouchableHighlight>
                    <TouchableHighlight style={styles.button}
                        onPress={this.game2Press}
                    >
                        <Text>
                            Game 2
                        </Text>
                    </TouchableHighlight>
                    <TouchableHighlight style={styles.button}
                        onPress={this.scoringPress}
                    >
                        <Text>
                            Scoring
                        </Text>
                    </TouchableHighlight>
                </View>
                
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    navbarContainer: {
        height: deviceHeight/6,
        width: deviceWidth,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "lightblue",
        flexDirection: "row"
    },
    contentContainer: {
        height: 5*(deviceHeight/6),
        width: deviceWidth,
    },
    background: {
        flex: 8,
        alignItems: 'space-between',
        justifyContent: 'space-between',
    },
    textContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {
        fontSize: 30,
        textAlign: 'center',
        justifyContent: 'center',
        fontWeight: 'bold',
        margin: 15,
        color: "blue",
        flexDirection: "row",
    },
    buttonContainer: {
        height: deviceHeight/8,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        margin: 5,
    },
    button: {
        height: 50,
        width: 80,
        borderColor: 'black',
        borderWidth: 2,
        alignItems: 'center',
        justifyContent: 'center',
        margin: 5,
    },
    buttonText: {
        color: 'black',
        fontSize: 15,
        textAlign: 'center',
    },
    scoreContainer: {
        height: deviceHeight/2,
        width: 5*(deviceHeight/8),
        textAlign: 'center',
        alignItems: 'center',
        flexDirection: 'column',
    },
    paragraph: {
        color: 'red',
        fontSize: 27,
        textAlign: 'center',
        fontWeight: "bold",
    },
});